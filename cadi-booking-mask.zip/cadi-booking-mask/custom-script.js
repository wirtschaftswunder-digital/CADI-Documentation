function checkStickyParents() {
    let parent = document.querySelector("#side-bar-wrapper");
    if (!parent) setTimeout(checkStickyParents, 500);
    else {
        while (parent) {
            const hasOverflow = getComputedStyle(parent).overflow;
            if (hasOverflow !== "visible") {
                parent.style.setProperty("overflow", "visible");
            }
            parent = parent.parentElement;
        }
    }
}
checkStickyParents();